
# Write a program to exchange the values of two numbers without using a temporary variable.

x = 10
y = 5
print("before exchange ---> ", x)
print("after exchange ---> ", y)
x, y = y, x

print("after exchange x ----> ", x)
print("after exchange y ----> ", y)
