# Write a program to read two numbers and print their quotient and remainder.


a = int(input("enter first number  "))
b = int(input("enter second number  "))

quotient = a//b
remainder = a % b

print("quotient -->", quotient)
print("remainder -->", remainder)
