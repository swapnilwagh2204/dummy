# Write a program to find modulus of a complex number 8+6j.


# first way

import math
num = 8+6j
print(type(num))
a = num.real
b = num.imag
mod = math.sqrt(math.pow(a, 2)+math.pow(b, 2))
print(mod)


# second way
print(abs(num))
