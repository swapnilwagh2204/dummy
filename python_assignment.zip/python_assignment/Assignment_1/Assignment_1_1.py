
# Write any python program that makes use of variables, constants, operators, atleast 5 keywords and print statements of different forms ?


x = 100
y = 50
print("addition---->", x+y)

print("substraction--->", x-y)
print("multiplication-->", x*y)
print("division--->", x / y)
print("remainder-->", x % y)
print("quotient-->", x//y)

print("power--> ", x**2)


name = "swapnil"
print(type(name))
print(type(x))

for i in range(10):
    if i % 2 == 0:
        print(i)

nm = input("Enter the name \n \n ")
if nm == name:
    print("name is correct")

else:
    print("name is wrong")
