from mypackage.hypen_sep import hypen_seperated
from mypackage.word_frequency import word_freq
from mypackage.common_char import common_chars
from mypackage.string_manipulation import str_manipulation


class Ipinvalid(Exception):
    def __init__(self, msg):
        super().__init__(msg)


while True:
    print("\n \n1.common characters \n2.word frequency \n3.string_manipulation \n4.hyphen_seperated \n")
    n = int(input(("please choose from the menu which code u want to perform ? ")))

    def ip(n):
        if n > 5:
            raise Ipinvalid("please enter the choice among stated above")
    try:
        if n == 1:
            st1 = input("Please enter string 1--->")
            st2 = input("Please enter string 2--->")
            op = common_chars(st1, st2)
            print(op)
        elif n == 2:
            st = input("Please enter string--->")
            op = word_freq(st)
            print(op)
        elif n == 3:
            st = input("Please enter string-->")
            op = str_manipulation(st)
            print(op)
        elif n == 4:
            ip = input("Please enter words -->")
            op = hypen_seperated(ip)
            print(op)
        elif n == 5:
            break
    except Ipinvalid as msg:
        print(msg)
