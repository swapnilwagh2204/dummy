def hypen_seperated(ip):
    ls=ip.split('-')
    ls=sorted(ls)
    return "-".join(ls)
    