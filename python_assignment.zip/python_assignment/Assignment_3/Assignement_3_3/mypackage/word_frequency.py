

def word_freq(word):
    dt = {}
    for i in list(set(word)):
        dct = {i: word.count(i)}
        dt.update(dct)
    return dt


word_freq("hello")
