def common_chars(st1, st2):
    common_characters = list(set(st1).intersection(set(st2)))
    return common_characters
