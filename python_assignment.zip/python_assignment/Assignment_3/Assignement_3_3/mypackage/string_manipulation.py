def str_manipulation(word):
    new_str=word[:2]+word[-2:]
    return new_str

