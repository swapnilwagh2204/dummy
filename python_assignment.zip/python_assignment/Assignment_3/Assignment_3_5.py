
# Write a function to compute 5/0 and use try/except to catch the exceptions?

def compute():
    try:
        op = 5/0
    except Exception as exp:
        print("Exception occcured here is --->", exp)


compute()
