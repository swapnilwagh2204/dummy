
# Write a program to illustrate the use of standard libraries (list, tuple, range, set, dict, str, int, math, random, enum, os, sys)


# list:
# ls = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# print(type(ls))


# tp = (1, 2, 3, 4, 5, 6)
# print(type(tp))

# range is used to make a list of numbers
# also it can be used to access the list elements with the index

# for i in range(0, 10):
#     print(i)

# for i in range(0, len(ls)):
#     print(i)

# set:

# st = set([1, 2, 3, 45])
# print(type(st))

# # no repetation of elements is allowed in set

# st1 = set([1, 2, 3, 3, 3])
# print(st1)


# dictionary:

# here data is present in the key value pair format(key:value)

# dct = {"name": "saurabh", "age": 25, "address": "mumbai", "mobile": 944444444}
# print(dct['name'])  # accessing dictionary data


# string:
# string is a immutable data type in python.
# st = "swapnil"
# print(type(st))


# integer:
# a = 10
# print(type(a))


# math library:
# math library consists of mathematical functions and operations.

# import math
# a = 2
# power = math.pow(a, 2)
# print(power)


# random.:
# it is built in module that we can use to make  random numbers.

import random
# random.seed(2)  # to restrict the randomness of the number
# print(random.random())  # generates a random number
# print(random.randint(10, 20))  # generate a random number between 10 and 20
# print(random.choice([1, 2, 3, 4, 5, 6, 7]))
# returns a random number between given sequence

# shuffle--> takes the sequence and shuffle it and save ...return none
# ls = [1, 2, 3, 4, 5]
# random.shuffle(ls)
# print(ls)


# sample
# takes a sequence and k..and returns random k elements from the sequence
# print(random.sample(ls, 2))

# enums:
# Enumerations in Python are implemented by using the module named “enum“.Enumerations are created using classes. Enums have names and values associated with them.


# Properties of enum:

# 1. Enums can be displayed as string or repr.

# 2. Enums can be checked for their types using type().

# 3. “name” keyword is used to display the name of the enum member.


# import enum


# class Student(enum.Enum):
#     name = "swapnil"
#     rollno = 1
#     marks = 100


# print(Student.rollno)
# print(repr(Student.name))
# print(type(Student.name))

# # enums are iterable
# for i in Student:
#     print(i)


# os

# The OS module in Python provides functions for interacting with the operating system
# import os
# print(os.getcwd())  # current working directory
# print(os.listdir())  # get files in current working directory
# # os.mkdir("sample")  # create directory  sample
# os.rmdir("sample")  # remove directory sample


# sys:

# The sys module in Python provides various functions and variables that are used to manipulate different parts of the Python runtime environment. It allows operating on the interpreter as it provides access to the variables and functions that interact strongly with the interpreter.


import sys
print(sys.version)


# The sys modules provide variables for better control over input or output. We can even redirect the input and output to other devices. This can be done using three variables –


# stdin
# stdout
# stderr


# for line in sys.stdin:
#     sys.stdout.write(line+" swapnil")
#     break


# print(sys.argv) #takes input from cmd
