# Write a program to raise a custom exception which takes a string message as attribute?
class Ipinvalid(Exception):
    def __init__(self, msg):
        super().__init__(msg)


def ip(n):
    if n == 0:
        raise Ipinvalid("please enter the number other than 0")


def compute(n):
    try:
        ip(n)
        op = 5/n
        print(op)
    except Ipinvalid as msg:
        print(msg)


n = int(input("Please enter the number --> "))
compute(n)
