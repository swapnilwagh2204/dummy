def fibonacci(n):
    a = 0
    b = 1
    ls = [a, b]
    for i in range(n):
        a, b = b, a+b
        ls.append(b)
    return ls


op = fibonacci(7)
print(op)
