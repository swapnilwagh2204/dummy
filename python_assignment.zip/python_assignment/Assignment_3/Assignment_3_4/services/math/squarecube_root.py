import math


def squareroot(n):
    return math.sqrt(n)


def cuberoot(n):
    return math.pow(n, 1/3)
