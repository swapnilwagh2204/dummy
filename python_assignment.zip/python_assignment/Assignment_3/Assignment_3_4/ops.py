from services.sorting.binary_sort import insertion_sort
ls1 = [2, 5, 7, 5, 3, 2, 4, 6, 7, 9]
ls2 = [5, 42, 34, 5, 6, 7, 66, 4, 3, 2]


def combine_sort(ls1, ls2):
    combined_list = ls1+ls2
    ls = insertion_sort(combined_list)
    return ls


op = combine_sort(ls1, ls2)
print(op)
