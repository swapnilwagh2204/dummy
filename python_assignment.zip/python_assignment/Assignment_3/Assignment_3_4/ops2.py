import math
from services.sorting.binary_sort import insertion_sort
ls = list(map(int, input("enter the numbers-->").split()))
sq_list = [int(math.pow(i, 2)) for i in ls]
print(ls)
print(sq_list)
op = insertion_sort(sq_list)
print(op)
