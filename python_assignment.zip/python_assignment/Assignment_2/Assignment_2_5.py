# Write a function that takes the path of a directory and prints out the paths files within that directory as well as any files present in the nested directories. (This function is similar to os.walk. Please don't use os.walk in your answer. We are interested in your ability to work with nested structures)


import os

# path = "/media/swapnil/work1/python_assignment"


def foo(path):
    content = os.listdir(path)

    for i in content:
        updated_path = path+"/"+i
        if os.path.isfile(updated_path):
            print(updated_path)
        elif os.path.isdir(updated_path):
            directory_contents = os.listdir(updated_path)
            print("--------")
            print(i+"\n")
            for i in directory_contents:
                print(updated_path+"/"+i)
            print("-------")


path = input("enter the path --> ")
foo(path)
