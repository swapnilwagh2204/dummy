# Write a program to find the sum of the digits of the number recursively upto n iterations?

def sum(n):
    if n == 0:
        return 0
    return (n % 10 + sum(int(n / 10)))


n = int(input("enter the number--->"))
op = sum(n)
print("sum of the digits:---->", op)
