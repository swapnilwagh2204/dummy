# Write a password generator program of 8 characters that contains at least one uppercase, one lower case, one digit and one special symbol? (Every new password should be different than the previously generated one).


import random
digits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
lower_char = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
              'i', 'j', 'k', 'm', 'n', 'o', 'p', 'q',
              'r', 's', 't', 'u', 'v', 'w', 'x', 'y',
              'z']

upper_char = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
              'I', 'J', 'K', 'M', 'N', 'O', 'p', 'Q',
              'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y',
              'Z']

special_symbol = ['@', '#', '$', '%', '=', ':', '?', '.', '/', '|', '~', '>',
                  '*', '(', ')', '<']


random_password = random.choice(
    digits)+random.choice(lower_char)+random.choice(upper_char)+random.choice(special_symbol)

all_list = digits+lower_char+upper_char+special_symbol
remaining_pass = random.choices(all_list, k=4)

password = random_password+"".join(remaining_pass)
print(password)
