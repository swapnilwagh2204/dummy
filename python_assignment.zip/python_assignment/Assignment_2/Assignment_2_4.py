# Given an array of ints length n, return an array with the elements "rotated left" so {1, 2, 3} yields each iteration until {2, 3, 1} comes. Eg:
# rotate_left3([5, 11, 9]) → [11, 9, 5]
# rotate_left3([7, 0, 0]) → [0, 0, 7]

def rotate_left3(ls, x):
    print(ls[x:]+ls[:x])


rotate_left3([5, 11, 9], -2)
rotate_left3([7, 0, 0], -2)
rotate_left3([1, 2, 3], -2)
