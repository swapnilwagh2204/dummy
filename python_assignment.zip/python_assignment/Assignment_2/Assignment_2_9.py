# Write a function that will take one list as input and return three different types of list as illustrated in the output. In object2, you can append a list containing triplet of a number but object 3 should be evaluated based on the elements present in the object2 (Note:You have to take care of both the space and time complexities as well)
# Input:
# object1 = [[1,1,1],[2,2,2],[3,3,3]]

# Output:
# object1 = [[1,1,1],[2,2,2],[3,3,3]]
# object2 = [[1,1,1],[2,2,2],[3,3,3],[4,4,4]]
# object3 = [[1,1,1],[2,4,2],[3,9,3],[4,16,4]]

# ls = []
import copy
object1 = [[1, 1, 1], [2, 2, 2], [3, 3, 3]]
object2 = copy.deepcopy(object1)
object2 = object2+[[4, 4, 4]]
object3 = [[i[0], i[0]**2, i[0]] for i in object2]
print(object1)
print(object2)
print(object3)
