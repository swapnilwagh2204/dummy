# Write a function to reverse words of the sentence?(Check the output carefully)
# Input:
# “I love programming.”
# Output:
# “.programming love I”

def rev(text):
    ls = text.split(" ")
    ls.reverse()
    first = ls[0][-1]+ls[0][0:-1]
    new_text = first + " " + " ".join(ls[1:])
    print(new_text)


text = input("Enter the text: ")
rev(text)
