# Write a program to illustrate the use of default, keyword, optional and variable length args (*args and **kwargs)?

# default:

def foo(a, b=10):
    print(a+b)


foo(a=10)


# variable arguments:

def foo1(*args):
    print(*args)


foo1("hii", "my", "naame", "is", "swapnil")


def foo2(**kwargs):
    for k, v in kwargs.items():
        print(k+" ----- "+v)


foo2(name="swapnil", sirname="wagh", city="nanded")


# keyword arguments

def foo3(a=10, b=20):
    print(a+b)


foo3(b=100, a=20)
