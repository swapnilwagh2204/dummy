
# Write a function that accepts a sequence of whitespace separated words as input and prints the words after removing all duplicate words and sorting them alphanumerically?
# (Both with and without second list)

words = "swapnil   wagh    india   usa   python   afour "


def foo(input_words):
    input_words = input_words.split()
    print(input_words)

    ls = sorted(set(input_words))
    print(" ".join(ls))


input_words = input("enter the words --> ")
foo(input_words)
