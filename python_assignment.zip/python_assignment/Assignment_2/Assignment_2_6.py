# Write a program to find the maximum of 2 numbers using normal function and then using ternary operator and then illustrate the same using lambda function ?


# using function :
# def max(a, b):
#     if a > b:
#         max = a
#     elif b > a:
#         max = b

#     print("maximum number-->", max)

# max(-1, 4)


# using ternary operator
# a = 100
# b = 80
# print("equal" if a == b else "a is greater than b " if a >
#       b else "a is less than b")


# using lambda:

def max(x, y): return x if (x > y) else y


print(max(-2, 3))
