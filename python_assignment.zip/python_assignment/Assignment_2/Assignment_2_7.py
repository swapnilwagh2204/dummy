# Write a program using loops and closure to find the multipliers of 4 (4,8,12,16,....,40)?


# using loops

for i in range(1, 11):
    print(i*4)


# using closure

