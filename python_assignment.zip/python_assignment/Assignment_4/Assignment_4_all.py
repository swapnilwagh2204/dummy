
# Write one liner list comprehension that takes a list and makes a new list that contains the square of all the even elements of this list?

# ls = [1, 2, 3, 4, 5, 6, 7]
# sq_list = [ls[i]**2 for i in range(len(ls)) if i % 2 == 0]
# print(sq_list)


# Write a program to create a list of tuples from given list having number and its square in each tuple? Also, convert the list of tuples to a dictionary. (Using Comprehension)

# tp = list(([(i, i**2) for i in ls]))
# print(tp)

# dt = {i[0]: i[1] for i in tp}
# print(dt)


# Create a Set comprehension to get the unique words in the string.
# st = "helloworld"
# unique_words = {i for i in st if st.count(i) == 1}
# print(unique_words)

# Create a List comprehension to get the files with .txt extension.
# ls = ["abc.txt", "pdq.jpg", "xyz.py", "ab.png", "park.java", "wwe.txt"]
# txt_list = [i for i in ls if i.split(".")[-1] == "txt"]
# print(txt_list)


# Create a generator expression to find the sum of cube of first 20 elements?

# gene_fun = (i**3 for i in range(20))
# print(sum(gene_fun))

# Create a Dictionary comprehension to get the length of each word in the list?
# ls = ["abc.txt", "pdq.jpg", "xyz.py", "ab.png", "park.java", "wwe.txt"]
# dict_comp = {i: len(i) for i in ls}
# print(dict_comp)


# Write a List comprehension to get numbers that are multiples of 2 as well as 3 upto 50.
# op_ls = [i for i in range(3, 50) if i % 2 == 0]
# print(op_ls)
